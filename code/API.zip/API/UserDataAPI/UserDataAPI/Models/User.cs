﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UserDataAPI.Models
{
    public class User
    {
        public string UserFName { get; set; }
        public string UserLName { get; set; }
        public string Id { get; set; }
    }
}
