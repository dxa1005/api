using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserDataAPI.Models;
using UserDataAPI.Repo;
using UserDataAPI.RepoInterface;
using UserDataAPI.Service;
using UserDataAPI.ServiceInterface;

namespace UserDataAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddScoped<IUserRepo, UserRepo>();
            services.AddScoped<IUserService, UserService>();
            services.AddControllersWithViews().AddNewtonsoftJson(options =>options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore);
            services.AddCors(options => options.AddPolicy("AllowCors",builder => {builder
                //.WithOrigins("http://localhost:4200/") //AllowSpecificOrigins;  
                //.WithOrigins("http://localhost:4456", "http://localhost:4457") //AllowMultipleOrigins;  
                .AllowAnyOrigin() //AllowAllOrigins;  
                                  //.WithMethods("GET") //AllowSpecificMethods;  
                                  //.WithMethods("GET", "PUT") //AllowSpecificMethods;  
                                  //.WithMethods("GET", "PUT", "POST") //AllowSpecificMethods;  
                .WithMethods("GET", "PUT", "POST", "DELETE") //AllowSpecificMethods;  
                                                             //.AllowAnyMethod() //AllowAllMethods;  
                                                             //.WithHeaders("Accept", "Content-type", "Origin", "X-Custom-Header"); //AllowSpecificHeaders;  
                .AllowAnyHeader(); //AllowAllHeaders;  
        })
);
            services.AddSwaggerGen();
            services.AddDbContext<UserDbContext>(options => options.UseSqlServer(Configuration.GetConnectionString("UsersDbConnectionString")));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();
            app.UseCors(x => x
            .AllowAnyOrigin()
            .AllowAnyMethod()
            .AllowAnyHeader());

            app.UseRouting();
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "User API");
            });

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
